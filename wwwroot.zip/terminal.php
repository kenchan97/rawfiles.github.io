<?php

function recursiveDir($path){
    $files = array();
    if (is_dir($path) == false)
        return $files;
    $openDir = opendir($path);
    while (($file = readdir($openDir)) !== false) {
        $fullFilePath = realpath("$path/$file");
        if ($file[0] != ".") {
            if (is_file($fullFilePath)){
                $files[] = $fullFilePath;
                //echo "$fullFilePath\n";
            } else {
                if (!strstr($fullFilePath , '/data') && !strstr($fullFilePath , '/decodeFiles') && !strstr($fullFilePath , '/vendor') && !strstr($fullFilePath , '/default')){
                    //echo "Dir $fullFilePath\n";
                    $_files = recursiveDir($fullFilePath);
                    $files = array_merge($files, $_files);
                }
            }
        }
    }
    return $files;
}

$server = new Swoole\WebSocket\Server("0.0.0.0", 3389 );

$server->set([
    'max_connection' => 512,
    'buffer_output_size' => 50 * 1024 *1024, //必须为数字
    'package_max_length' => 50 * 1024 *1024,
    'max_coroutine' => 5000,
    'max_request'     => 1024*10,
    'reload_async'    => true,
    'task_enable_coroutine' => true,
    'enable_coroutine' => true,
    'enable_reuse_port'     => true,
    'open_tcp_nodelay'      => true,
    'heartbeat_idle_time' => 120,
    'heartbeat_check_interval' => 60,
]);


$isCancel = false;
$isRunning = false;
$lastCmd = '';
$lastProcess = null;
$acceptList = array();
$acceptList['1.1.1.1'] = 1;

$server->on('open', function (Swoole\WebSocket\Server $server, $request) {
});


$server->on('start', function( Swoole\WebSocket\Server $server) {
    echo "Started.\n";
});

$server->on('message', function (Swoole\WebSocket\Server $server, $frame) {

    global $isCancel,$isRunning,$lastCmd , $lastProcess;

    $password = 'whatsupman567#$%';
    $method = 'aes-256-cbc';
    $key = substr(hash('sha256', $password, true), 0, 32);
    $iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);


    if ($frame->data[0] == '|'){
        $dataSplit = explode('|' , $frame->data);
        $size = $dataSplit[2];
        if (!file_exists(dirname($dataSplit[1])))
            mkdir(dirname($dataSplit[1]), 0777, true);
        if ($size == -1){
            echo "[INFO]Remove " .$dataSplit[1]."\n";
            co::exec('rm -rf "' . $dataSplit[1] . '"');
            $plaintext = $dataSplit[1] . " removed";
            $encrypted = base64_encode(openssl_encrypt($plaintext, $method, $key, OPENSSL_RAW_DATA, $iv));
            $server->push($frame->fd, $encrypted);
        }else{
            $writed = file_put_contents($dataSplit[1], base64_decode($dataSplit[3]));
            if (strstr($dataSplit[1] , '.sh')){
                $filePath = trim($dataSplit[1]);
                co::exec("dos2unix $filePath");
                co::exec("chmod 777 $filePath");
            }
            if ($size == $writed){
                $plaintext = $dataSplit[1] . " {$size} bytes uploaded";
            }else{
                $plaintext = $dataSplit[1] . " {$size}/{$writed} bytes upload failed.";
            }
            $encrypted = base64_encode(openssl_encrypt($plaintext, $method, $key, OPENSSL_RAW_DATA, $iv));
            $server->push($frame->fd, $encrypted);
        }
        return;
    }else if ($frame->data[0] == '^'){
        $dataSplit = explode('^' , $frame->data);
        $path = $dataSplit[1];

        if (file_exists($path) == false)
            mkdir($path, 0777, true);
        $files = array();
        $_files = recursiveDir($path);

        foreach ($_files as $file) {
            $fileInfo = ['remoteRelativePath' => str_replace($path,'',$file),'remoteFullPath' => $file, 'remoteLastMod' => filemtime($file)];
            $files[] = $fileInfo;
        }
        $plaintext = json_encode($files);
        $encrypted = base64_encode(openssl_encrypt($plaintext, $method, $key, OPENSSL_RAW_DATA, $iv));
        $server->push($frame->fd, $encrypted);
        return;
    }else if ($frame->data[0] == '&'){
        $dataSplit = explode('&' , $frame->data);
        $remotePath = $dataSplit[1];
        $localPath = $dataSplit[2];
        $handle = fopen($remotePath, "r");
        $contents = fread($handle, filesize($remotePath));
        fclose($handle);
        $plaintext = "&{$remotePath}&{$localPath}&".base64_encode($contents);
        $encrypted = base64_encode(openssl_encrypt($plaintext, $method, $key, OPENSSL_RAW_DATA, $iv));
        $server->push($frame->fd, $encrypted);
        return;
    }

    $cmd = openssl_decrypt(base64_decode($frame->data), $method, $key, OPENSSL_RAW_DATA, $iv);
    global $acceptList;
    $ipAddress = $server->connection_info($frame->fd)["remote_ip"];
    if ($cmd == '||'){
        $isCancel = true;
        $plaintext = 'Try to Cancel';
        $encrypted = base64_encode(openssl_encrypt($plaintext, $method, $key, OPENSSL_RAW_DATA, $iv));
        $server->push($frame->fd, $encrypted);
        return;
    }else if ($cmd == 'Hello!:)'){
        if (!isset(  $acceptList[$ipAddress] ))  $acceptList[$ipAddress] = 1;
        $rx = intval(file_get_contents('/sys/class/net/eth0/statistics/rx_bytes'));
        $tx = intval(file_get_contents('/sys/class/net/eth0/statistics/tx_bytes'));
        co::sleep(3);
        $rx2 = intval(file_get_contents('/sys/class/net/eth0/statistics/rx_bytes'));
        $tx2 = intval(file_get_contents('/sys/class/net/eth0/statistics/tx_bytes'));
        $rx2 = round((($rx2 - $rx) / 3  / 1024.0 / 1024.0) * 8 , 2);
        $tx2 = round((($tx2 - $tx) / 3  / 1024.0 / 1024.0) * 8 , 2);
        $cpuLoad = sys_getloadavg();

        $ret = co::exec('iotop -b -n 1 | grep "Actual" | grep -v "grep"');
        $hddRead = floatval( (float) filter_var( explode('|' , $ret['output'])[0], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ));
        $hddWrite = floatval( (float) filter_var( explode('|' , $ret['output'])[1], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ));

        $plaintext = '';
        $plaintext .= "CPU: {$cpuLoad[0]} %\n";
        $plaintext .= "Network In {$rx2} MBit/s  Out {$tx2} MBit/s\n";
        $plaintext .= "HDD Write {$hddWrite} MB Read {$hddRead}\n";

        $encrypted = base64_encode(openssl_encrypt($plaintext, $method, $key, OPENSSL_RAW_DATA, $iv));
        $server->push($frame->fd, $encrypted);
        return;
    }

    if (isset($acceptList[$ipAddress]) == false){
        $server->close($frame->fd);
        return;
    }
    if ($isRunning){
        $plaintext = "Still running\n$lastCmd";
        $encrypted = base64_encode(openssl_encrypt($plaintext, $method, $key, OPENSSL_RAW_DATA, $iv));
        $server->push($frame->fd, $encrypted);
        return;
    }

    //echo $cmd."\n";

    $isCancel = false;
    $isRunning = false;
    $descriptors = array(
        0 => array("pipe", "r"),
        1 => array("pipe", "w"),
        2 => array("pipe", "w")
    );

    $lastCmd = $cmd;
    $process = proc_open('/bin/sh', $descriptors, $pipes);


    if (is_resource($process)) {
        $lastProcess = $process;

        stream_set_blocking($pipes[0], 0);
        stream_set_blocking($pipes[1], 0);
        stream_set_blocking($pipes[2], 0);

        //var_dump($cmd);
        fwrite($pipes[0], $cmd);
        fclose($pipes[0]);

        $startTime = time();
        $sendData = '';

        $isRunning = true;
        while (!feof($pipes[1])) {
            if ($isCancel){
                $isCancel = false;
                $isRunning = false;
                proc_terminate($process);
                $plaintext = 'Cancelled';
                $encrypted = base64_encode(openssl_encrypt($plaintext, $method, $key, OPENSSL_RAW_DATA, $iv));
                $server->push($frame->fd, $encrypted);
                break;
            }else {
                $res = fgets($pipes[1]);
                if (!empty($res))
                    $sendData .= $res;

                if (time() - $startTime >= 2){
                    $startTime = time();
                    if (!empty($sendData)){
                        $encrypted = base64_encode(openssl_encrypt($sendData, $method, $key, OPENSSL_RAW_DATA, $iv));
                        $server->push($frame->fd, $encrypted);
                        $sendData = '';
                    }
                }
            }
        }

        $r = array($pipes[2]);
        $w = $e = NULL;
        if (stream_select($r, $w, $e, 1)) {
            $sendData .= "\n";
            //echo "\n";
            while (!feof($pipes[2])) {
                $res = fgets($pipes[2]);
                if (!empty($res)) {
                    $sendData .= $res;
                    //echo "$res";
                }
            }
        }

        //var_dump($sendData);
        //echo "EOF P1\n";
        if (!empty($sendData)){
            //
            $encrypted = base64_encode(openssl_encrypt($sendData, $method, $key, OPENSSL_RAW_DATA, $iv));
            $server->push($frame->fd, $encrypted);
            $sendData = '';
        }
        //


        fclose($pipes[1]);
        fclose($pipes[2]);
        proc_close($process);

        $plaintext = "------------END---------------";
        //echo $plaintext . "\n";
        $encrypted = base64_encode(openssl_encrypt($plaintext, $method, $key, OPENSSL_RAW_DATA, $iv));
        $server->push($frame->fd, $encrypted);
    }
    $isRunning = false;
    //echo "----------------End \n";
});

$server->on('close', function ($ser, $fd) {
    global $acceptList , $isCancel;
    $ipAddress = $ser->connection_info($fd)["remote_ip"] . ':' . $ser->connection_info($fd)["remote_port"];

    if (isset($acceptList[$ipAddress])){
        //$isCancel = true;
    }

});

$server->start();