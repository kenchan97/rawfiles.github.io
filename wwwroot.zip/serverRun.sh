#!/bin/sh
ulimit -SHn 262140

while true; do
	####################
	script=serverRun.php
	if test -f "/home/wwwroot/$script"; then
		logSize=`wc -c /home/wwwroot/$script.log | awk '{print $1}'`
		if [ $logSize -gt 10485760 ];then
		    rm -f /home/wwwroot/$script.log
		fi
		count=`ps -fe |grep "$script" | grep -v "grep" | wc -l`
		if [ $count -lt 1 ];then
		    nohup /usr/bin/php /home/wwwroot/$script >> /home/wwwroot/$script.log &
		    echo "Start script [$script] ".$(date +%Y-%m-%d_%H:%M:%S) >> /home/wwwroot/system.log
		fi
	fi
	ping -c 30 127.0.0.1
done