<?php

ini_set("memory_limit", "-1");
set_time_limit(0);
ignore_user_abort(true);
date_default_timezone_set('PRC');
error_reporting(E_ALL);
ini_set('display_errors', 'On');

Swoole\Runtime::enableCoroutine($flags = SWOOLE_HOOK_ALL);

go(function() {
    $now = date("F j, Y, g:i a");
    echo "\n\n============{$now}============\n";
    echo "Swoole ". SWOOLE_VERSION . "\n";
    echo __FILE__ . "\n";
    system('whoami');
    echo "========================\n";

    $cmd = 'aria2c --enable-rpc --rpc-listen-all=true --allow-overwrite=true --rpc-allow-origin-all -c -D'; co::exec($cmd);

    $execConfig = dirname(__FILE__) . '/exec.config.json';
    $runScriptList = [];
    if (file_exists($execConfig)) $runScriptList = json_decode(file_get_contents($execConfig) , true);
    else file_put_contents($execConfig , json_encode($runScriptList , JSON_PRETTY_PRINT) );

    $modTime = filemtime($execConfig);
    $myHostname = gethostname();
    $loopTime = 0;
    while(true){
        foreach ($runScriptList as $runScript) {
            $fileName = basename($runScript['path']);
            $logPath = $runScript['path'] . '.log';
            $cmd = 'ps -fe | grep "'.$fileName.'" | grep -v "grep" | wc -l';

            $output = shell_exec($cmd);
            $runningCount = intval($output);
            if ($runningCount == 0){

                if (empty($runScript['hostname']) || strstr($runScript['hostname'] ,$myHostname )){
                    if (empty($runScript['forbiddenHostname']) || !strstr($runScript['forbiddenHostname'] ,$myHostname )) {
                        if (!file_exists($runScript['path'])){
                            echo "[ERROR]{$runScript['path']} not found. \n";
                            continue;
                        }
                        $cmd = 'nohup ' . $runScript['exec'] . ' >> ' . $logPath . ' &';

                        $now = date("F j, Y, g:i a");
                        echo "[INFO]{$now} start {$runScript['path']} \n{$cmd}\n";
                        system($cmd);
                        echo "[INFO]{$cmd} OK\n\n";
                        co::sleep(2);
                    }
                }
            }
        }
        if (file_exists($execConfig) && filemtime($execConfig) != $modTime){
            $modTime = filemtime($execConfig);
            echo "[INFO]Exec Config Updated.\n";
            if (file_exists($execConfig))
                $runScriptList = json_decode(file_get_contents($execConfig) , true);
        }

        if (time() - $loopTime >= 600){
            $loopTime = time();
            $_now = date("F j, Y, g:i a");
            echo "[INFO]{$_now} ".__FILE__." Running.\n";
        }

        co::sleep(5);
    }
    $_now = date("F j, Y, g:i a");
    echo "[INFO]{$_now} ".__FILE__." End.\n";
});



?>